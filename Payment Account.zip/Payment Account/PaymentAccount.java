// 1. The Main Executable Class
public class PaymentAccount {
    private double balance;

    public PaymentAccount(double balance) {
        this.balance = balance;
    }

    // The method declares the checked exception with 'throws'
    public void withdraw(double amount) throws InsufficientFundsException {
        if (amount > balance) {
            throw new InsufficientFundsException(amount - balance);
        }
        balance -= amount;
        System.out.println("Withdrawn: UGX " + amount + " | New balance: UGX " + balance);
    }

    // Demo Engine
    public static void main(String[] args) {
        PaymentAccount acc = new PaymentAccount(50_000);
        
        try {
            acc.withdraw(30_000);   // OK: Balance becomes 20,000
            acc.withdraw(40_000);   // Throws exception: Short by 20,000
        } catch (InsufficientFundsException e) {
            System.out.println("ERROR: " + e.getMessage());
            System.out.println("Shortfall: UGX " + e.getShortfall());
        }
    }
}

// 2. Custom Checked Exception Class
class InsufficientFundsException extends Exception {
    private final double shortfall;

    public InsufficientFundsException(double shortfall) {
        super("Insufficient funds. You are short by UGX " + shortfall);
        this.shortfall = shortfall;
    }

    public double getShortfall() {
        return shortfall;
    } // Closing brace added here
}