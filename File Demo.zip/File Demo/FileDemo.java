import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class FileDemo {
    public static void main(String[] args) {
        // Determine a safe working path location
        String targetPath = System.getProperty("user.dir") + File.separator + "data.txt";
        File file = new File(targetPath);

        // Fallback to the system's temporary directory if workspace write access is denied
        try {
            if (!file.exists() && !file.createNewFile()) {
                targetPath = System.getProperty("java.io.tmpdir") + File.separator + "data.txt";
            }
        } catch (IOException e) {
            targetPath = System.getProperty("java.io.tmpdir") + File.separator + "data.txt";
        }

        // Initialize data.txt with sample content safely
        prepareSampleData(targetPath);

        System.out.println("Reading from file: " + targetPath + "\n");

        // --- FIXED WITH TRY-WITH-RESOURCES ---
        // The resource is declared in the try() header and closes automatically 
        try (BufferedReader br = new BufferedReader(new FileReader(targetPath))) {
            
            String line = br.readLine();
            System.out.println(line);

        } catch (IOException e) {
            System.out.println("File error: " + e.getMessage());
        }
        // br.close() is safely triggered implicitly here even if errors occur
    }

    // Helper method to populate text lines into the file safely
    private static void prepareSampleData(String filePath) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(filePath))) {
            bw.write("Hello from the data.txt file! Try-with-resources is running smoothly.");
        } catch (IOException e) {
            System.out.println("Could not initialize file content: " + e.getMessage());
        }
    }
}
